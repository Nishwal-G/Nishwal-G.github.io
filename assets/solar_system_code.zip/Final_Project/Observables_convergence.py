#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Convergence of Observables:
    
Using the Verlet N-Body simulation from Simulation_Code.py, the perihelia,
aphelia and periods of specified planets are plotted as they change with the 
timestep dt. This allows to find the timestep over which the observables 
converge. 

Name: Nishwal Gora
Student Number: S2179934
"""

import argparse
import matplotlib.pyplot as plt
from Simulation_Code import run_simulation

#Setting up inputs for the code.
parser = argparse.ArgumentParser(description='Plot perihelion, aphelion, and period changes for various dt')
parser.add_argument('--input_file', type=str, required=True, help='Path to the input file')
parser.add_argument('--total_time', type=float, required=True, help='Total simulation time')
parser.add_argument('--planet', type=str, required=True, help='Planet to plot convergence for')
args = parser.parse_args()

dt_values = [20, 15, 10, 5, 1, 0.5,0.1]
closest_approaches = []
furthest_approaches = []
orbital_periods = []

for dt in dt_values:
    numstep = int(args.total_time * 365.25 / dt)
    #Here the results are called in from run_simulation():
    perihelions, aphelions, orbital_periods_array, energy_deviation, min_distance_moon, max_distance_moon, particles_list = run_simulation(dt, numstep, args.input_file)


    #Extracting planet names from particles_list
    planet_names = []
    for particle in particles_list:
        planet_names.append(particle.label)

    #Finding the index of the specified planet directly
    if args.planet in planet_names:
        planet_index = planet_names.index(args.planet)
    else:
        print(f"Planet {args.planet} not found.")
        continue

    #Accesssing data using planet_index 
    if args.planet == "Moon":
        closest_approaches.append(min_distance_moon)
        furthest_approaches.append(max_distance_moon)
        orbital_periods.append(orbital_periods_array[planet_index])
    else:
        closest_approaches.append(perihelions[planet_index])
        furthest_approaches.append(aphelions[planet_index])
        orbital_periods.append(orbital_periods_array[planet_index])



plt.figure(figsize=(15, 5))

#Making sure that the labels change depending on whether the observable is a
#moon or a planet.
if args.planet == "Moon":
    closest_label = "Perigee"
    furthest_label = "Apogee"
else:
    closest_label = "Perihelion"
    furthest_label = "Aphelion"

distance_label = "Distance (AU)"
period_label = "Orbital Period (Earth years)"
dt_label = "dt (log scale)"


#Plotting each of the observables against dt in log scale

#Closest Approach (Perigee or Perihelion)
plt.subplot(1, 3, 1)
plt.plot(dt_values, closest_approaches, 'o-', label=f"{closest_label} {args.planet}")
plt.xlabel(dt_label)
plt.ylabel(distance_label)
plt.title(f"{args.planet} {closest_label} vs dt")
plt.xscale('log')

#Furthest Approach (Apogee or Aphelion)
plt.subplot(1, 3, 2)
plt.plot(dt_values, furthest_approaches, 'o-', label=f"{furthest_label} {args.planet}")
plt.xlabel(dt_label)
plt.ylabel(distance_label)
plt.title(f"{args.planet} {furthest_label} vs dt")
plt.xscale('log')

#Orbital Period
plt.subplot(1, 3, 3)
plt.plot(dt_values, orbital_periods, 'o-', label="Orbital Period")
plt.xlabel(dt_label)
plt.ylabel(period_label)
plt.title(f"{args.planet} Period vs dt")
plt.xscale('log')

plt.tight_layout()
plt.legend()
plt.show()





