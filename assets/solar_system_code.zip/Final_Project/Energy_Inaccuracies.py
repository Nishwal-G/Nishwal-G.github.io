#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Energy Inaccuracies - 

This code is set to run the velret simulation of the solar_system.txt over
a given period of time. By varying the dt values in the code, the energy 
inaccuracy at each of these timsteps can be established, and convergence can be 
tested for. 

Name: Nishwal Gora
Student Number: S2179934

"""


import argparse
import numpy as np
import matplotlib.pyplot as plt
from Simulation_Code import run_simulation

def main():
    #Setting up inputs for the code.
    parser = argparse.ArgumentParser(description='Calculate energy inaccuracy for various dt values.')
    parser.add_argument('--input_file', type=str, required=True, help='Path to the input file')
    parser.add_argument('--time', type=float, required=True, help='Total simulation time in years')
    args = parser.parse_args()

    #Here, the dt values to be tested are defined. Since the simulation would
    #take five minutes to run dt = 0.1 and over 50 to run dt = 0.01 for a time
    #of 10 years, only till dt = 0.5 was used. However, the energy converged at
    #this point. 
    dt_values = np.array([20, 15, 10, 5, 1, 0.5, 0.1])
    energy_inaccuracies = []

    #Here the total simulation time is converted from years to days. 
    time = args.time * 365.25
    
    #Running simulations and collect energy inaccuracies
    for dt in dt_values:
        numstep = int(time/ dt)
        #Here the results are called in from run_simulation():
        perihelions, aphelions, orbital_periods_array, energy_deviation, min_distance_moon, max_distance_moon, particles_list = run_simulation(dt, numstep, args.input_file)
        energy_inaccuracies.append(energy_deviation)
        
        #Printing the energy inaccuracy for each dt to eyeball how long it 
        #takes for the simulation to be run for each dt. This also allows to 
        #see when the energy inaccuracy drops below 0.01%. 
        print(f'dt: {dt:.3f}, Energy Inaccuracy: {energy_deviation}')

    

    #Plotting How energy inaccuracy changes for various dt values.
    plt.figure(figsize=(10, 6))
    plt.plot(dt_values, energy_inaccuracies, marker='o', linestyle='-', color='blue')
    plt.xscale('log')
    plt.xlabel('dt (days) (log scale)')
    plt.ylabel('Energy Inaccuracy (∆E/E0)')
    plt.title('How the total energy deviated from an initial value for various time-steps')
    plt.show()
    plt.close()

if __name__ == "__main__":
    main()





