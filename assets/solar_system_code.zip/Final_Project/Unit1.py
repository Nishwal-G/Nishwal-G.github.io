#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Project Unit 1: Building two functions which use Particle3D to compute the 
separations between N particles, and the forces and potential on these N 
particles.

Author: Nishwal Gora
Number: S2179934

"""

from particle3D import Particle3D
import numpy as np


def compute_separations(particles):
    """
    Returns an numpy array of 3D vectors, each of which 
    correspond to the separation between the ith and jth particles 
    from Particle3D class. Each element [i,j,k] represents the separation
    between particles i and j in the kth dimension. 
    
    The array extends into three dimensions, which two dimensions tracing
    the separation between the ith and jth particle, with the third dimension
    giving the (x, y, z) component of said separation.
    
    Separations are found by subtracting the position of the ith particle from 
    the jth one.
    
    n = number of particles.
    
    Input:
    -------
    particles = list
    
    Output:
    -------
    separations = array of vectors
    
    """
    
    #First we must compute the length of our list to find out how many 
    #particles we are dealing with. 
    n = len(particles)
    #Next, we need to define an empty array of dimensions (n,n,3) which will be 
    #filled with the separations which we will calculate:
    separations = np.zeros((n,n,3))
    #Now to calculate separations: We create an outer loop which goes 
    #through the positions of the i'th elements in particles, and nested 
    #within it is another which starts from i and goes till n, to calculate
    #the separation of the i'th particle with every particle after it. We can
    #do this because, for example, if we have the separation between particles 
    #(a,b) and (a,c), then the separations (b,a) and (c,a) are negative the 
    #separation vector of the former two separations. Hence they need not be
    #calculated a second time.
    for i in range(n):
        for j in range(i, n):
            #Here we find the serpation between i and j
            separation = particles[i].position - particles[j].position
            #Here, we define the elements of our array
            separations[i,j] = separation
            separations[j,i] = -separation
    
    return separations


def compute_forces_potential(particles, separations):
    """
    1) Returns an array of dimensions (n,3) in which each row represents the 
    force acting on particle on the nth particle. Each row has three floats
    corresponding to the xyz values of the force. Each row in the forces array
    represents the force vector acting on the ith particle. 
    
    Here the (i,j) term gives the jth component of the total force acting on 
    particle i. 
    
    2) Returns the total potential of the system. 
    
    Input:
    -------
    particles = list
    separations = array
    
    Output:
    -------
    forces = array 
    total_potential = float 
    
    """
    #First we must compute the length of our list to find out how many 
    #particles we are dealing with. 
    n = len(particles)
    #We now create an empty array to store the forces acting on each particle
    #due to the other particles. 
    forces = np.zeros((n,3))
    #We can also set our initial total potential energy to 0, then as we 
    #iterate through the lists, we add up the necessary potentials due to each
    #pair:
    total_potential = 0
    #Define G (in units AU):
    G = 8.887692593e-10
    #Similarly to the compute_separations function, we need to iterate across 
    #all n particles, calculating the forces on them due to particles after 
    #them in the list:
    for i in range(n):
        #Here we go from i+1 to n as a particle cannot exert a folce on itself
        #(the force will be undefined), But also to avoid double counting
        #when calculating total potential. 
        for j in range(i+1, n):
            #Now, we need to call back the separation between particles i and j
            separation = separations[i,j]
            #Next, we will need to use the modulus of this vector
            sep_mod = np.linalg.norm(separation)
            
            #Now we can define the force between particle j and i as:
            force = -(G * particles[i].mass * particles[j].mass / sep_mod**3)*separation
            
            #Forces on the ith particle must be updated for each j:
            forces[i] = forces[i] + force
            
            #Using the third law, to find the total force on j due to i, we
            #flip the sign on the force:
            forces[j] = forces[j] - force
            
            #We calculate the potential of particle i due to particle j:
            potential = -G * particles[i].mass * particles[j].mass / sep_mod
            
            #Now we calculating the total potential, not needing to divide by 2
            #,as by starting from i+1 for j, we avoid double counting:
            total_potential = total_potential + potential
            
    return forces, total_potential






