#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Verifying Kepler's third law -

Verlet Simulation for N-Body system of objects from the class Particle3D, 
using the compute_separations and compute_forces_potential functions from the 
Unit1 file of the solar system modelling project. 

This file forms the core integration loop for any N body system. Here, 
the input (N-Body system) can be chosen, and the positions of the particles 
written onto an output file of choice. Further various observables such as the
perihelion, aphelion and orbital period (in days) of bodies in the N-body
system are calculated and printed. 

Further, using the orbital period and semi_major axis (calculated using the
perihelion and aphelion), Kepler's Third Law showing teh relationship between 
the orbital period and semi_major axis can be verified.

Name: Nishwal Gora
Student Number: S2179934
"""

import numpy as np
import matplotlib.pyplot as plt
import argparse
from particle3D import Particle3D
from scipy.signal import find_peaks
from scipy.stats import linregress
from scipy.optimize import curve_fit

#Importing basic functions from 'Unit1.py'
from Unit1 import compute_separations, compute_forces_potential

#Here a linear model is set up so that a best fit line can be drawn through the 
#plot showing Kepler's third law. 
def linear_model(x, m, c):
    return m * x + c

def average_orbital_period(positions,times):
    '''

    Calculates the average orbital period based on the radial distance peaks.

    This function determines the orbital period by calculating the distance of a body
    from the origin at each timestep, finding peaks in these distances, and computing
    the mean time difference between these peaks.

    Parameters
    ----------
    positions : array
        An array of position vectors of the body, where each row represents the position
        at a timestep.
    times : array
        An array of times corresponding to each position vector.

    Returns
    -------
    float
        The average orbital period of the body, calculated as the mean of the time
        differences between peaks in the radial distance from the origin. Returns NaN
        if no complete rotation is observed.
    '''


    #Calculating the radial distance of the body from the origin 
    #at each time step. np.linalg.norm computes magnitude of the position 
    #vectors along axis=1 (row-wise), resulting in a 1D array where each element 
    #is the distance of the planet from the origin at each time step.
    distance = np.linalg.norm(positions, axis = 1)
    #This will pick out the indices of the peaks occur in the list above
    peaks, _ = find_peaks(distance)
    #This now finds the times (in days) at these indices
    peak_times = times[peaks]
    #Finding the difference in time for each planet between these peaks allows
    #for to find the time it takes to reach back this peak distance, which is 
    #approximately the periodic time. 
    periods = np.diff(peak_times)
    
    #This ensures that the list has at least one period, i.e. at least one 
    #complete rotation has happened. 
    if len(periods) > 0:
        #Mean value to find the average of all the period calculated over all
        #the orbits completed. This gives a more accurate value for the period.
        return np.mean(periods)
    else:
        #Ensuring that is a period is not completed, that NaN is printed. 
        return np.nan
    
def calculate_neptune_orbital_period(positions, times):
    """
    Calculates Neptune's orbital period using unwrapped angular displacement.

    Due to Neptune's nearly circular orbit, traditional methods based on radial distance
    peaks are less effective. This function calculates the orbital period by measuring
    the angular displacement in polar coordinates and determining the time to complete
    a full 2π radian rotation.

    Parameters
    ----------
    positions : array
        An array of Cartesian position vectors of Neptune
    times : array
        An array of times corresponding to each position vector.

    Returns
    -------
    float
        The time taken for Neptune to complete one full orbit, calculated using
        angular displacement. Returns NaN if a full orbit is not completed within
        the timeframe of the data provided.
    
    """
    #Calculate angular positions from the x and y values of the positions of
    #Neptune. 
    angles = np.arctan2(positions[:,1], positions[:,0])

    #np.arctan2 is defined from -π to π. Hence, beyond this, angles may see
    #sudden angular discontinuities. np.unwrap detects these and adds or 
    #subtracts 2π where necessary to ensure a sequence of angles that change
    #continuously. 
    unwrapped_angles = np.unwrap(angles)

    #Here the total angular displacement of neptune over the simulation is 
    #calculated by subtracting the final angular displacement from the
    #initial angular displacement. 
    total_rotation = unwrapped_angles[-1] - unwrapped_angles[0]

    #Here, it is checked if at least one period is completed. 
    if np.abs(total_rotation) >= 2 * np.pi:
        #If a full orbit is detected, full_rotation_index finds the index in 
        #the times array corresponding to the completion of the first full 
        #orbit. It does this by identifying the first instance where the absolute 
        #difference between the unwrapped angles and the initial unwrapped 
        #angle exceeds 2π radians. 
        full_rotation_index = np.argmax(np.abs(unwrapped_angles - unwrapped_angles[0]) >= 2 * np.pi)
        #Below returns the time between the index at which the first 
        #orbital period is completed and the original time.
        return times[full_rotation_index] - times[0]
    else:
        #Ensuring that is a period is not completed, that NaN is printed. 
        return np.nan
    

def main():
    parser = argparse.ArgumentParser(description='N-Body Simulation Parameters')
    parser.add_argument('--total_time', type=int, help='Number of integration steps', required=True)
    parser.add_argument('--dt', type=float, help='Time step size', required=True)
    parser.add_argument('--input_file', type=str, help='Name of the input file', required=True)
    parser.add_argument('--super_jupiter', type=str, choices=['yes', 'no'], help='Multiply Jupiter mass by 20: yes or no', required=True)
    args = parser.parse_args()
    
    # Prompting for input file name, which is inputed in console
    filename = args.input_file
    # Opening the file
    filein = open(filename, "r")
    #Reading the lines of the input file
    data = filein.readlines()
    #Closing the file once reading is completed
    filein.close()
    # Creating list for Particle3D objects
    particles_list = []

    
    for line in data:
        #Selecting only non-empty (non-white space) characters
        if line.strip():
            #Calling in static method read_line from particle 3D, and setting
            #each line equal to the object particle, as each line is based on
            #The class particle3D
            particle = Particle3D.read_line(line)
            #Filling the empty list created above with with Particle3D objects
            particles_list.append(particle)
    
    #If super_jupiter is initiated, then the mass of the jupier must be 
    #multiplied by 20 for the remainder of the simulation.
    if args.super_jupiter == 'yes':
        for particle in particles_list:
            if particle.label == "Jupiter":
                particle.mass = 20*particle.mass


    # Set up simulation parameters:
    # about 10 years of simulation with 1 day timesteps
    dt = args.dt  
    numstep = int(args.total_time*365.25/dt)

    # Initial conditions of the system
    particles = particles_list
    time = 0.0

    #Static method com_velocity(particles) was called in from the class
    #Particle3D. 
    com_vel = Particle3D.com_velocity(particles)
    #For each particle (given dummy variable name 'particle') in the list 
    #above, the velocity of each particle was subtracted from the centre of 
    #mass velocity found using the method in Particle3D.
    for particle in particles:
        particle.velocity = particle.velocity - com_vel

    # Initialise arrays that we will store results in
    n = len(particles)
    times = np.zeros(numstep)
    energy = np.zeros(numstep)
    positions = np.zeros((n, numstep, 3))

    # To compute the initial forces, first the initial separations need to 
    # be used. Here separations in equated to the function to calculate it 
    #written in unit 1.
    separations = compute_separations(particles)
    #Forces and potential_energy are both called in. 
    forces, potential_energy = compute_forces_potential(particles, separations)    
    # Main time integration loop
    
    #Enumerate takes the particles list that we have created and does two 
    #things. It rturns both the index of each planet "i" and the planet 
    #itself "particle". From this, it is possible to set what the index of the 
    #various necessary planets are. In this case, two reference planets the
    #Earth and Sun are necessary to index for later calculations. This allows
    #for flexibility in the input file, as it doesn't matter the order in which
    #the file presents the planets.
    for i, particle in enumerate(particles):
        if particle.label == "Sun" :
            sun_index = i
        elif particle.label == "Earth":
            earth_index = i
        elif particle.label == "Moon":
            moon_index = i
        elif particle.label == "Neptune":
            neptune_index = i
    
    # Initialise min/max distance arrays for each planet from the Sun.
    
    #Here, np.full() is used to create a array of length n (The number of
    #planets), all with  a value infinity filling each spot. If it was 
    #initialised with zeros, then the actual computed distances (which will 
    #always be positive values greater than zero) will never be smaller than 
    #the initial values. Therefore, the minimum distance values will 
    #never be updated from zero, leading to incorrect results.
    min_distance_planet = np.full(n, np.inf)
    #Here, the lowest possible value (0) for the distance for each planet
    #from the sun is used to initialist. 
    max_distance_planet = np.zeros(n)

    # Initialise min/max distance for Moon from Earth. 
    
    #Here arrays are not necessary as we are finding the value of the distance
    #form the moon from earth, and not concerned with any other planet.
    min_distance_moon = np.inf
    max_distance_moon = 0
    
    
    semi_major_axes_cubed = []
    orbital_periods_squared = []
    eccentricities = []
            
    for i in range(numstep):
        times[i] = time
        time += dt

        #For the all the jth particles in the list with n particles,
        #the position is updated using the second order approximation, as is
        #required in the Verlet simulation. Here the force on the jth particle
        #is the argument in the function.
        for j in range(n):
            particles[j].update_position_2nd(forces[j], dt)   
        #These positions are stored in an empty 3D array 'positions' defined
        #above. Here, each element refers to the position of the jth element at
        #the ith timestep. 
            positions[j,i] = particles[j].position 
        #Here again, separations is calculated using the newly updated position
        #, and the new force acting on the particles at these positions is 
        #updated, along with the potential energy. 
        separations = compute_separations(particles)
        new_forces, potential_energy = compute_forces_potential(particles, separations)  
        #Using the verlet method, the velocity is updated using the average
        #force between the prior and current position. 
        for j in range(n):
            particles[j].update_velocity(0.5*(forces[j] + new_forces[j]) ,dt)
            
        #For the next iteration, the initial force is set to new_force
        forces = new_forces
        #Static Method from Particle3D is called in to calculate the total 
        #kinetic energy of the particles.
        kinetic_energy = Particle3D.total_kinetic_energy(particles)
        #Here the total energy i scalcualted for each iteration. 
        total_energy = kinetic_energy + potential_energy
        #The energies for each iteration (timestep) are stored in a vector
        #to be plotted agaist time later. 
        energy[i] = total_energy
        
        for j in range(n):
            #For all planets other than the sun, this calculates the distance
            #from the sun. This happens for each numstep. 
            if j != sun_index:
                planet_distance = np.linalg.norm(particles[j].position - particles[sun_index].position)
                #This line updates the minimum distance array for the current 
                #planet. If the newly calculated planet_distance is 
                #smaller than the existing value in min_distance_sun[j], it 
                #replaces it. It is finding the minimum between previous
                #min_distance_sun[j]'s and the new planet_distance calculated
                #in each iteration. 
                min_distance_planet[j] = min(min_distance_planet[j], planet_distance)
                #Similarly, this line updates the maximum distance array for 
                #the current planet. If the newly calculated distance is larger 
                #than the existing value in max_distance_sun[j], it replaces it.
                #As above, it is comparing previous max_distances to the 
                #distance in the new iteration.
                max_distance_planet[j] = max(max_distance_planet[j], planet_distance)

        # Update distance for Moon from Earth
            moon_distance = np.linalg.norm(particles[moon_index].position - particles[earth_index].position)
            #This line updates the minimum distance of the Moon from the Earth. 
            #If the newly calculated distance is smaller than min_distance_moon, 
            #it replaces it. It is finding the minimum between previous
            #min_distance_moon[j]'s and the new moon_distance calculated in 
            #each iteration. 
            min_distance_moon = min(min_distance_moon, moon_distance)
            #This line updates the maximum distance of the Moon from the Earth. 
            #If the newly calculated distance is larger than max_distance_moon, 
            #it replaces it. The same logic as above is used, but for
            #maximum each iteration.
            max_distance_moon = max(max_distance_moon, moon_distance)
        
    
    #Here, we print the the perihelion and aphelion are defined as pulling out 
    #the max and min distance of planet j from the list. 
    
    for j, particle in enumerate(particles):
        if j != sun_index:
            if j == neptune_index:
                orbital_period = calculate_neptune_orbital_period(positions[j], times)
            else:
                orbital_period = average_orbital_period(positions[j], times)
                
            perihelion = min_distance_planet[j]
            aphelion = max_distance_planet[j]
            
            print(f"{particle.label} Orbital Period: {orbital_period} Days")
            print(f"{particle.label}: Perihelion = {perihelion} AU, Aphelion = {aphelion} AU")

            #It must be ensured that at least one orbit has been completed
            #in order for the following calculations to be valid. 
            if not np.isnan(orbital_period):
                #To ensure that we are only choosing the planets which orbit 
                #around the sun, the moon must be excluded. This is because 
                #Kepler's law apply when the reference planet around which the 
                #bodies orbit is the same. 
                if j != moon_index:
                    semi_major_axis_cubed = ((perihelion + aphelion) / 2) ** 3
                    semi_major_axes_cubed.append(semi_major_axis_cubed)
                    orbital_periods_squared.append(orbital_period ** 2)
                    e = 1 - perihelion/(semi_major_axis_cubed)**(1 / 3)
                    eccentricities.append(e)
                    print(f"{particle.label} eccentricity: {e}")
     
    #Plotting orbits of all planets around the Sun and the Moon's orbit around
    #the Earth. From this effect on the orbits due to the the introduction of 
    #super Jupiter into the system can be analsysed. 
    for j in range(n):
        #The plotting 
        if j != sun_index: 
            if j == moon_index:
                plt.title('Moon Orbit Around Earth')
                plt.plot(positions[moon_index, :, 0] - positions[earth_index, :, 0], positions[moon_index, :, 1] - positions[earth_index, :, 1])
            else:
                plt.title(f'Orbit of {particles[j].label} Around the Sun')
                plt.plot(positions[j, :, 0] - positions[sun_index, :, 0], positions[j, :, 1] - positions[sun_index, :, 1])
                plt.xlabel('X / AU')
                plt.ylabel('Y / AU')
                plt.savefig(f"Orbit_{particles[j].label}_Super_Jup.png")
                plt.close()
    
    
    moon_orbital_period = average_orbital_period(positions[moon_index], times)
    print(f"Moon Orbital Period around Earth: {moon_orbital_period} Days")
    print(f"Moon: Perigee = {min_distance_moon} AU, Apogee = {max_distance_moon} AU")
    
    #Appending the lists above made for a simpler way to append without 
    #exactly deifning the size of an array. However to test the linerality of 
    #a fit using scipy.stats, the lists can be transformed to arrays so more
    #mathematical functions can be applied onto them. 
    semi_major_axis_cubed = np.array(semi_major_axis_cubed)
    orbital_periods_squared = np.array(orbital_periods_squared)
    
    
    #The values stored in the arrays are changed to log scales, as this is what
    #their plot is. 
    log_semi_major_axes_cubed = np.log(semi_major_axes_cubed)
    log_orbital_periods_squared = np.log(orbital_periods_squared)
    
    #Here values of the slope and R^2 values and gotten from the data using
    #scipy.stats. 
    slope, intercept, r_value, p_value, std_err = linregress(log_semi_major_axes_cubed, log_orbital_periods_squared)

    #A linear curvefit is used on the data so that the gradient and y-intercept
    #can be extracted from it. From this, a best fit line can be drawn through 
    #the data. 
    params, params_covariance = curve_fit(linear_model, log_semi_major_axes_cubed, log_orbital_periods_squared)

    #Here the slope (m_fit) and y-intercept (c_fit) are extracted from the 
    #parameters. 
    m_fit, c_fit = params
    
    print(f"Slope of the regression line: {slope}")
    print(f"Coefficient of determination (R²): {r_value**2}")
    #Using the linear model function
    best_fit_y = linear_model(log_semi_major_axes_cubed, m_fit, c_fit)

    #Plotting the data points
    plt.scatter(log_semi_major_axes_cubed, log_orbital_periods_squared, color='blue')

    #Plotting the best-fit line
    plt.plot(log_semi_major_axes_cubed, best_fit_y, color='red', linestyle='-', linewidth=2)

    #To prove the linear relationship between semi_major axis cubed and 
    #orbital period squared, it is first necessary to plot them to recognise 
    #a linear fit. A log-log scale is used as the quantities are raised to 
    #powers and this scale will provide a linear analogue. 
    plt.xlabel('Log of Semi-major Axis cubed (log(AU^3))')
    plt.ylabel('Log of Orbital Period Squared (log(days^2))')
    plt.title("Verification of Kepler's Third Law")
    plt.show()

# This python standard code makes it so that the "main"
# function is only called when you run the file directly,
# not when you just import it from another python file.
if __name__ == "__main__":
    main()