"""
Core Integration Loop for various input and outputs- 

Verlet Simulation for N-Body system of objects from the class Particle3D, 
using the compute_separations and compute_forces_potential functions from the 
Unit1 file of the solar system modelling project. 

This file forms the core integration loop for any N body system. Here, 
the input (N-Body system) can be chosen, and the positions of the particles 
written onto an output file of choice, which can then be used in an animation
to see how the positions of particles in the N-body system change over time.
Further, functions to calculate the perihelion, aphelion and orbital period of 
each planet are used. A special function is written for neptune to approximate
its orbit using angular properties since its orbit is approximately circular.  

Name: Nishwal Gora
Student Number: S2179934
"""
import numpy as np
import matplotlib.pyplot as plt
import argparse
from particle3D import Particle3D
from scipy.signal import find_peaks

#Importing basic functions from 'Unit1.py'
from Unit1 import compute_separations, compute_forces_potential


def energy_inaccuracy(energy):
    '''
    Calculates the inaccuracy in the energy of the system over time.

    This function computes the difference between the maximum and minimum energy values
    within a given array of energy measurements. The inaccuracy is then determined
    by dividing this difference by the initial energy value.

    Parameters
    ----------
    energy : array
        An array of energy values for each timestep in the simulation.

    Returns
    -------
    float
        The relative inaccuracy of the system's energy, calculated as the absolute
        value of the difference between the maximum and minimum energies, divided by
        the initial energy.

    '''
    #Picking out minimum and maximum total energies from the energy list 
    #which creates an energy for each timestep
    min_E = np.min(energy)
    max_E = np.max(energy)
    del_E = max_E - min_E
    #Picking out from the initial energy from "energy"
    E_0 = energy[0]
    return np.abs(del_E/E_0)

def average_orbital_period(positions,times):
    '''

    Calculates the average orbital period based on the radial distance peaks.

    This function determines the orbital period by calculating the distance of a body
    from the origin at each timestep, finding peaks in these distances, and computing
    the mean time difference between these peaks.

    Parameters
    ----------
    positions : array
        An array of position vectors of the body, where each row represents the position
        at a timestep.
    times : array
        An array of times corresponding to each position vector.

    Returns
    -------
    float
        The average orbital period of the body, calculated as the mean of the time
        differences between peaks in the radial distance from the origin. Returns NaN
        if no complete rotation is observed.
    '''


    #Calculating the radial distance of the body from the origin 
    #at each time step. np.linalg.norm computes magnitude of the position 
    #vectors along axis=1 (row-wise), resulting in a 1D array where each element 
    #is the distance of the planet from the origin at each time step.
    distance = np.linalg.norm(positions, axis = 1)
    #This will pick out the indices of the peaks occur in the list above
    peaks, _ = find_peaks(distance)
    #This now finds the times (in days) at these indices
    peak_times = times[peaks]
    #Finding the difference in time for each planet between these peaks allows
    #for to find the time it takes to reach back this peak distance, which is 
    #approximately the periodic time. 
    periods = np.diff(peak_times)
    
    #This ensures that the list has at least one period, i.e. at least one 
    #complete rotation has happened. 
    if len(periods) > 0:
        #Mean value to find the average of all the period calculated over all
        #the orbits completed. This gives a more accurate value for the period.
        return np.mean(periods)
    else:
        #Ensuring that is a period is not completed, that NaN is printed. 
        return np.nan
    
def calculate_neptune_orbital_period(positions, times):
    """
    Calculates Neptune's orbital period using unwrapped angular displacement.

    Due to Neptune's nearly circular orbit, traditional methods based on radial distance
    peaks are less effective. This function calculates the orbital period by measuring
    the angular displacement in polar coordinates and determining the time to complete
    a full 2π radian rotation.

    Parameters
    ----------
    positions : array
        An array of Cartesian position vectors of Neptune
    times : array
        An array of times corresponding to each position vector.

    Returns
    -------
    float
        The time taken for Neptune to complete one full orbit, calculated using
        angular displacement. Returns NaN if a full orbit is not completed within
        the timeframe of the data provided.
    
    """
    #Calculate angular positions from the x and y values of the positions of
    #Neptune. 
    angles = np.arctan2(positions[:,1], positions[:,0])

    #np.arctan2 is defined from -π to π. Hence, beyond this, angles may see
    #sudden angular discontinuities. np.unwrap detects these and adds or 
    #subtracts 2π where necessary to ensure a sequence of angles that change
    #continuously. 
    unwrapped_angles = np.unwrap(angles)

    #Here the total angular displacement of neptune over the simulation is 
    #calculated by subtracting the final angular displacement from the
    #initial angular displacement. 
    total_rotation = unwrapped_angles[-1] - unwrapped_angles[0]

    #Here, it is checked if at least one period is completed. 
    if np.abs(total_rotation) >= 2 * np.pi:
        #If a full orbit is detected, full_rotation_index finds the index in 
        #the times array corresponding to the completion of the first full 
        #orbit. It does this by identifying the first instance where the absolute 
        #difference between the unwrapped angles and the initial unwrapped 
        #angle exceeds 2π radians. 
        full_rotation_index = np.argmax(np.abs(unwrapped_angles - unwrapped_angles[0]) >= 2 * np.pi)
        #Below returns the time between the index at which the first 
        #orbital period is completed and the original time.
        return times[full_rotation_index] - times[0]
    else:
        #Ensuring that is a period is not completed, that NaN is printed. 
        return np.nan
    

def main():
    parser = argparse.ArgumentParser(description='N-Body Simulation Parameters')
    parser.add_argument('--total_time', type=int, help='Total time in years', required=True)
    parser.add_argument('--dt', type=float, help='Time step size', required=True)
    parser.add_argument('--input_file', type=str, help='Name of the input file', required=True)
    parser.add_argument('--output_file', type=str, help='Name of the output XYZ file', required=True)
    parser.add_argument('--observables_file', type=str, help='Name of the file to store observables', required=True)
    args = parser.parse_args()
    
    #Prompting for input file name, which is inputed in console
    filename = args.input_file
    #Opening the file
    filein = open(filename, "r")
    #Reading the lines of the input file
    data = filein.readlines()
    #Closing the file once reading is completed
    filein.close()
    #Creating list for Particle3D objects
    particles_list = []
    
    for line in data:
        #Selecting only non-empty (non-white space) characters
        if line.strip():
            #Calling in static method read_line from particle 3D, and setting
            #each line equal to the object particle, as each line is based on
            #The class particle3D
            particle = Particle3D.read_line(line)
            #Filling the empty list created above with with Particle3D objects
            particles_list.append(particle)
            
    #Opening a file called xyz_file to write onto, tracking the change in 
    #position of each of the particles involved. 
    xyz_file = open(args.output_file, "w")
    observables_file = open(args.observables_file, "w")

    #Set up simulation parameters:
    dt = args.dt  
    numstep = int(args.total_time*365.25/dt)

    #Initial conditions of the system
    particles = particles_list
    time = 0.0

    #Static method com_velocity(particles) was called in from the class
    #Particle3D. 
    com_vel = Particle3D.com_velocity(particles)
    #For each particle (given dummy variable name 'particle') in the list 
    #above, the velocity of each particle was subtracted from the centre of 
    #mass velocity found using the method in Particle3D.
    for particle in particles:
        particle.velocity = particle.velocity - com_vel

    # Initialise arrays that we will store results in
    n = len(particles)
    times = np.zeros(numstep)
    energy = np.zeros(numstep)
    positions = np.zeros((n, numstep, 3))

    # To compute the initial forces, first the initial separations need to 
    # be used. Here separations in equated to the function to calculate it 
    #written in unit 1.
    separations = compute_separations(particles)
    #Forces and potential_energy are both called in. 
    forces, potential_energy = compute_forces_potential(particles, separations)    
    # Main time integration loop
    
    #Enumerate takes the particles list that we have created and does two 
    #things. It rturns both the index of each planet "i" and the planet 
    #itself "particle". From this, it is possible to set what the index of the 
    #various necessary planets are. In this case, two reference planets the
    #Earth and Sun are necessary to index for later calculations. This allows
    #for flexibility in the input file, as it doesn't matter the order in which
    #the file presents the planets.
    for i, particle in enumerate(particles):
        if particle.label == "Sun" :
            sun_index = i
        elif particle.label == "Earth":
            earth_index = i
        elif particle.label == "Moon":
            moon_index = i
        elif particle.label == "Neptune":
            neptune_index = i
    
    # Initialise min/max distance arrays for each planet from the Sun.
    
    #Here, np.full() is used to create a array of length n (The number of
    #planets), all with  a value infinity filling each spot. If it was 
    #initialised with zeros, then the actual computed distances (which will 
    #always be positive values greater than zero) will never be smaller than 
    #the initial values. Therefore, the minimum distance values will 
    #never be updated from zero, leading to incorrect results.
    min_distance_planet = np.full(n, np.inf)
    #Here, the lowest possible value (0) for the distance for each planet
    #from the sun is used to initialist. 
    max_distance_planet = np.zeros(n)

    # Initialise min/max distance for Moon from Earth. 
    
    #Here arrays are not necessary as we are finding the value of the distance
    #form the moon from earth, and not concerned with any other planet.
    min_distance_moon = np.inf
    max_distance_moon = 0

            
    for i in range(numstep):
        times[i] = time
        time += dt

        #For the all the jth particles in the list with n particles,
        #the position is updated using the second order approximation, as is
        #required in the Verlet simulation. Here the force on the jth particle
        #is the argument in the function.
        for j in range(n):
            particles[j].update_position_2nd(forces[j], dt)   
        #These positions are stored in an empty 3D array 'positions' defined
        #above. Here, each element refers to the position of the jth element at
        #the ith timestep. 
            positions[j,i] = particles[j].position 
        #Here again, separations is calculated using the newly updated position
        #, and the new force acting on the particles at these positions is 
        #updated, along with the potential energy. 
        separations = compute_separations(particles)
        new_forces, potential_energy = compute_forces_potential(particles, separations)  
        #Using the verlet method, the velocity is updated using the average
        #force between the prior and current position. 
        for j in range(n):
            particles[j].update_velocity(0.5*(forces[j] + new_forces[j]) ,dt)
            
        #For the next iteration, the initial force is set to new_force
        forces = new_forces
        #Static Method from Particle3D is called in to calculate the total 
        #kinetic energy of the particles.
        kinetic_energy = Particle3D.total_kinetic_energy(particles)
        #Here the total energy i scalcualted for each iteration. 
        total_energy = kinetic_energy + potential_energy
        #The energies for each iteration (timestep) are stored in a vector
        #to be plotted agaist time later. 
        energy[i] = total_energy
        
        for j in range(n):
            #For all planets other than the sun, this calculates the distance
            #from the sun. This happens for each numstep. 
            if j != sun_index:
                planet_distance = np.linalg.norm(particles[j].position - particles[sun_index].position)
                #This line updates the minimum distance array for the current 
                #planet. If the newly calculated planet_distance is 
                #smaller than the existing value in min_distance_sun[j], it 
                #replaces it. It is finding the minimum between previous
                #min_distance_sun[j]'s and the new planet_distance calculated
                #in each iteration. 
                min_distance_planet[j] = min(min_distance_planet[j], planet_distance)
                #Similarly, this line updates the maximum distance array for 
                #the current planet. If the newly calculated distance is larger 
                #than the existing value in max_distance_sun[j], it replaces it.
                #As above, it is comparing previous max_distances to the 
                #distance in the new iteration.
                max_distance_planet[j] = max(max_distance_planet[j], planet_distance)

        # Update distance for Moon from Earth
            moon_distance = np.linalg.norm(particles[moon_index].position - particles[earth_index].position)
            #This line updates the minimum distance of the Moon from the Earth. 
            #If the newly calculated distance is smaller than min_distance_moon, 
            #it replaces it. It is finding the minimum between previous
            #min_distance_moon[j]'s and the new moon_distance calculated in 
            #each iteration. 
            min_distance_moon = min(min_distance_moon, moon_distance)
            #This line updates the maximum distance of the Moon from the Earth. 
            #If the newly calculated distance is larger than max_distance_moon, 
            #it replaces it. The same logic as above is used, but for
            #maximum each iteration.
            max_distance_moon = max(max_distance_moon, moon_distance)
        
        #ensuring that xyz_file for each numstep has the number of particles
        #in the input list, the positions of which each added to a new line. 
        xyz_file.write(f"{len(particles)}\n")
        #Here the relevant numstep is typed above the set of particles which
        #form rows beneath it. 
        xyz_file.write(f"points {i}\n")
        #Now, we loop over all the particle positions in particle_list to add
        #each of them to the xyz_file. 
        for particle in particles:
            #Stripping the object for only it's label and position, and leaving
            #which are what are needed to be written onto the output file. This
            #is done using the method __str__ from Particle3D. 
            particle_position = particle.__str__()
            xyz_file.write(particle_position + "\n")
    
    #Here, we write the data onto the observable_file, by calling 
    #back in the functions created above. Further, the perihelion and 
    #aphelion are defined as pulling out the max and min distance of planet
    #j from the list. 
    
    for j, particle in enumerate(particles):
        if j != sun_index:
            if neptune_index:
                if j == neptune_index:
                    orbital_period = calculate_neptune_orbital_period(positions[j], times)
                else:
                    orbital_period = average_orbital_period(positions[j], times)
                
                perihelion = min_distance_planet[j]
                aphelion = max_distance_planet[j]
                if j != moon_index:
                    print(f"{particle.label} Orbital Period: {orbital_period} Days")
                    print(f"{particle.label}: Perihelion = {perihelion} AU, Aphelion = {aphelion} AU")
                    observables_file.write(f"{particle.label} Orbital Period: {orbital_period} Days\n")
                    observables_file.write(f"{particle.label}: Perihelion = {perihelion} AU, Aphelion = {aphelion} AU\n")

    for j in range(n):
        #Each orbit is plotted here, with special attention paid to the moon
        #ensuring that it's positions are taken with respect to the earth. 
        if j != sun_index: 
            if j == moon_index:
                plt.title('Moon Orbit Around Earth')
                plt.plot(positions[moon_index, :, 0] - positions[earth_index, :, 0], positions[moon_index, :, 1] - positions[earth_index, :, 1])
            else:
                plt.title(f'Orbit of {particles[j].label} Around the Sun')
                plt.plot(positions[j, :, 0] - positions[sun_index, :, 0], positions[j, :, 1] - positions[sun_index, :, 1])
                plt.xlabel('X / AU')
                plt.ylabel('Y / AU')
                plt.savefig(f"Orbit_{particles[j].label}.png")
                plt.close()         
   
    moon_orbital_period = average_orbital_period(positions[moon_index], times)
    print(f"Moon Orbital Period around Earth: {moon_orbital_period} Days")
    print(f"Moon: Perigee = {min_distance_moon} AU, Apogee = {max_distance_moon} AU")
    observables_file.write(f"Moon Orbital Period around Earth: {moon_orbital_period} Days\n")
    observables_file.write(f"Moon: Perigee = {min_distance_moon} AU, Apogee = {max_distance_moon} AU\n")

    E_deviation = energy_inaccuracy(energy)
    print("Energy Deviation (∆E/E0): " + str(E_deviation))
    observables_file.write("Energy Deviation (∆E/E0): " + str(E_deviation) + "\n")
    
    xyz_file.close()
    observables_file.close()

# This python standard code makes it so that the "main"
# function is only called when you run the file directly,
# not when you just import it from another python file.
if __name__ == "__main__":
    main()

