Testing Report Using Simulation- Nishwal Gora (S2179934)


In reality the entire project can be tested using Unit4.py. However, in order to make testing various parts of the simulation easier, various code, pertaining to different parts of the report are made available here. NOTE: solar_system.txt and mini_system.txt in this file have changed 1P/Halley to Halley_Comet due to directory issues caused using a "/". 

1) *Using Unit4.py:*


The argparse package was used, allowing for inputs of: numstep, dt, input_file, output_file and obserbales_file to be modified. In the python console, the command that must be entered is:

%run Unit4.py --total_time <insert> --dt <insert> --input_file <insert> --output_file <insert> --observables_file <insert>

Eg. %run Unit4.py --numstep 500 --dt 0.5 --input_file solar_system.txt --output_file positions_out.txt --observables_file observables.txt

This will output a file positions_out.txt for an N-body system within the file solar_system.txt. This output file will carry the positions for 500*365.25/0.5 steps (numstep), which each time step (dt) being 0.5 days. It will also the perihelion and aphelion of the planets orbiting the sun (and of the moon around the earth) (in AU), along with their periods (in days), in the file observables.txt. These observables are also printed in the python console.

2) *Using Energy_inaccuracies.py:*

%run Energy_inaccuracies.py --input_file <insert> --time <insert>

Eg. %run Energy_inaccuracies.py --input_file mini_system.txt --time 10

This plot the energy inaccuracies for the simulation as a function of dt. dt's are hardcoded and can be changed. In the report (20, 15, 10, 5, 1, 0.5, 0.1) were plotted. 

3) *Using Observables_convergence.py*

%run Observables_convergence.py --input_file <insert> --total_time <insert> --planet <insert>

Eg. %run Observables_convergence.py --input_file mini_system.txt --total_time 10 --planet <Earth>

This will plot how the aphelion, perihelion and orbital period of a chosen planet converge as a function of dt.

4) *kepler_verified.py*

%run kepler_verified.py --total_time <insert> --dt <insert> --input_file <insert> --super_jupiter no

Eg. %run kepler_verified.py --total_time 500 --dt 0.5 --input_file solar_system.txt --super_jupiter no 

This will run the Verlet simulation and also plot how T^2 varies with a^3 at a set dt. It also account for whether Jupiter's mass should be multiplied by twenty (yes) or not (no).

5) *Simulation_Code.py* 

This does not need to be opened, but simply compiles all the functions in Unit4.py and makes the entire Verlet Simulation a function. In this way it can be called in to use in the files named above.  


