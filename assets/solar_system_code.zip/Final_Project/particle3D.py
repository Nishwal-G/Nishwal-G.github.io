"""
CompMod Ex2: Particle3D, a class to describe point particles in 3D space

An instance describes a particle in Euclidean 3D space: 
velocity and position are [3] arrays

Author: Nishwal Gora
Number: S2179934

"""
import numpy as np


class Particle3D(object):
    """
    Class to describe point-particles in 3D space

    Attributes
    ----------
    label: name of the particle
    mass: mass of the particle
    position: position of the particle
    velocity: velocity of the particle

    Methods
    -------
    __init__
    __str__
    kinetic_energy: computes the kinetic energy
    momentum: computes the linear momentum
    update_position_1st: updates the position to 1st order
    update_position_2nd: updates the position to 2nd order
    update_velocity: updates the velocity

    Static Methods
    --------------
    read_file: initializes a P3D instance from a file handle
    total_kinetic_energy: computes total K.E. of a list of particles
    com_velocity: computes centre-of-mass velocity of a list of particles
    """

    def __init__(self, label, mass, position, velocity):
        self.label = str(label)
        self.mass = float(mass)
        self.position = np.array(position)
        self.velocity = np.array(velocity)
        
        #These are only our mandotory parameters to define a particle. 
        #We intorudce force later which as a non-mandatory paramater. 
        
       

    def __str__(self):
        """
        Return an XYZ-format string. The format is
        label    x  y  z

        Returns
        -------
        str
        """
        ...
        return f"{self.label} {self.position[0]} {self.position[1]} {self.position[2]}"

    def kinetic_energy(self):
        """
        Returns the kinetic energy of a Particle3D instance

        Returns
        -------
        ke: float
            1/2 m v**2
        """

        return (1/2)*self.mass*((np.linalg.norm(self.velocity))**2)

    def momentum(self):
        """
        Returns the momentum of a Particle3D instance. It does so 
        by multiplying the mass of that ("self") instance by the magnitude
        of its own ("self") velocity. 
        
        The output is an numpy array. 
        """
        return  (self.mass)*(self.velocity)

    def update_position_1st(self, dt):
        """
        This updates that particular instance's ("self") position by using 
        the first order kinematics equation r(t+dt) = r(t) + dt*v(t). In
        other words is moved by a distance r(t+dt) - r(t) in the time dt, 
        assuming it's velocity at t is v(t).
        
        The output is an numpy array. 
        """
        self.position = self.position + dt*(self.velocity)
        

    def update_position_2nd(self, force, dt):
        """
        This updates that particular instance's ("self") position by using 
        the second order kinematics equation r(t+dt) = r(t) + dt*v(t) +
        dt^2*a(t).In other words is moved by a distance r(t+dt) - r(t) in the time dt, 
        assuming it's velocity at t is v(t) and an acceleration a(t). 
        
        this accelration at t is computed as force/self.mass (the mass of the 
        specific instance)
        
        The output is an numpy array. 
        """
        self.position = self.position + dt*(self.velocity) + (dt**2)*force/(2*self.mass) 
         

    def update_velocity(self, force, dt):
        """
        This updates that particular instance's ("self") position by using 
        the kinematics equation v(t+dt) = v(t) + dt*a(t).In other words this is
        the change in velocity, v(t+dt) - v(t) in the time dt, 
        assuming it's acceleration at t is a(t). 
        
        this accelration at t is computed as force/self.mass (the mass of the 
        specific instance)
        
        The output is an numpy array.
        """
        self.velocity = self.velocity + dt*force/(self.mass)
        

    @staticmethod
    def read_line(line):
        """
        Creates a Particle3D instance given a line of text.

        The input line should be in the format:
        label   <mass>  <x> <y> <z>    <vx> <vy> <vz>

        Parameters
        ----------
        filename: str
            Readable file handle in the above format

        Returns
        -------
        p: Particle3D
        """
        ...
        
        col = line.split()
        label = str(col[0])
        mass = float(col[1])
        position = np.array([float(col[2]), float(col[3]), float(col[4])])
        velocity = np.array([float(col[5]),float(col[6]),float(col[7])])
        
        return Particle3D(label, mass, position, velocity)

    @staticmethod
    def total_kinetic_energy(particles):
        """
        An empty KE_array is created. This is then filled with with the kinetic
        energy of each particle in the array particles. The sum of KE_array is
        then found to find the total Kinetic energy, which is just a float. 
        """
        ...
        
        KE_array = []
        for p in particles:
            KE_array.append(p.kinetic_energy())
        
        KE_total = np.sum(KE_array)
        
        return KE_total

    @staticmethod
    def com_velocity(particles):
        """
        Computes the CoM velocity of a list of P3D's

        Parameters
        ----------
        particles: list
            A list of Particle3D instances

        Returns
        -------
        com_vel: array
            Centre-of-mass velocity
        """
        ...
        
        mass_array = []
        for p in particles: 
            mass_array.append(p.mass)
            
        mass_total = np.sum(mass_array)
        
        lin_mom_array = []
        for p in particles:
            lin_mom_array.append(p.momentum())
        
        lin_mom_sum = np.sum(lin_mom_array, axis = 0)
        
        com_vel = lin_mom_sum/mass_total
        
        return com_vel